import { Component } from '@angular/core';


@Component({
  selector: 'app-root',
  templateUrl: './adminpage.component.html',
  styleUrls: ['./adminpage.component.css']
})

export class AdminpageComponent {
  title = 'adminpage';
}
